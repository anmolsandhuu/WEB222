// All you JavaScript code for assignment 4 should be in this file
// declaring the variables
var condition = "English",	Maxx = 0,	Minn = 0,	area = 0,	continent = "",	title_sub = "",	condition_lang = "";

// functions for different properties 
function OneH_Mill()
{
	condition = "OneH_Mill";
	Maxx = 8000000000;
	Minn = 100000000;
	
	area = "";
	continent = "";
	title_sub = " - Population greater than 100 million";
	insert_table();
}

function Two_mill()
{
	condition = "Two_mill";
	Maxx = 2000000;
	Minn = 1000000;
	area = "";
	continent = "";
	title_sub = " - Population between 1 and 2 million";

	insert_table();
}

function One_millkm_Ama()
{
	condition = "One_millkm_Ama";
	Maxx = 0;
	Minn = 0;
	area = 1000000;
	continent = "Americas";
	title_sub = " - Area greater than 1 million Km2, Americas";

	insert_table();

}

function All_asia()
{
	condition = "All_asia";
	Maxx = 0;
	Minn = 0;
	area = 0;
	continent = "Asia";
	title_sub = " - All countries in Asia";

	insert_table();
	
}

function English()
{
	condition = "English";
	Maxx = 0;
	Minn = 0;
	area = 0;
	continent = "";
	title_sub = " – Country / Dep. Name in English";

	insert_table();
}

function Hindi()
{
	condition = "Hindi";
	Maxx = 0;
	Minn = 0;
	area = 0;
	continent = "";
	title_sub = " – Country / Dep. Name in Hindi (हिंदी)";

	insert_table();
}

// First Function that will run when the page loads 
window.onload = function() 
{
  insert_table();
  
	document.querySelector("#menu_41").addEventListener("click", English);
    document.querySelector("#menu_45").addEventListener("click", Hindi);
	document.querySelector("#menu_21").addEventListener("click", OneH_Mill);
	document.querySelector("#menu_22").addEventListener("click", Two_mill);
	document.querySelector("#menu_31").addEventListener("click", One_millkm_Ama);
	document.querySelector("#menu_32").addEventListener("click", All_asia);
  
}

// Main function populating the Table
function insert_table()
{
	var title = document.querySelector("#subtitle");
	title.innerHTML="";
	var head = document.createElement("h4");
	head.appendChild(document.createTextNode("List of Countries and Dependencies"+ title_sub));
	title.appendChild(head);
	
	var	table_dev = document.querySelector("#outputTable");
		
	while (document.querySelector("#outputTable").childNodes.length > 5)
	{
		table_dev.removeChild(table_dev.childNodes[3]);
	}
	
	// for loop looping through the Countries array

  countries.forEach(
	  count => 
    {	
	
	
		if ( ( (condition == "English" ||  condition == "Hindi" )&& Maxx == 0 && Minn == 0 ) 
		|| ( (condition == "OneH_Mill" || condition == "Two_mill") && (count.Population > Minn && count.Population < Maxx)) 
		|| ( condition == "One_millkm_Ama" && count.AreaInKm2 > area && count.Continent == "Americas" ) 
		|| ( condition == "All_asia" && count.Continent == "Asia") )
		{
		
      var img = document.createElement("img"), td_img = document.createElement("td"),	tr = document.createElement("tr"),tbody = document.createElement("tbody"), flag_code = count.Code, flag_img = flag_code.toLowerCase() + ".png";
     
      		flagimg_locate = "flags/" + flag_img;
			img.src = flagimg_locate;
			img.alt = flag_code;
			img.height = "20";
			img.width = "30";
		
			td_img.appendChild(img);
			tr.appendChild(td_img);
	
	
			var td_code = document.createElement("td");
			td_code.appendChild(document.createTextNode(flag_code));
			tr.appendChild(td_code);
		
		
			var td_name = document.createElement("td");
			
			// Language in which data to be shown
     if (condition == "Hindi")
       {
				condition_lang = count.Name.Hindi;
      }
      else  
      {
        condition_lang = count.Name.English;
      };
			
			td_name.appendChild(document.createTextNode(condition_lang));
			tr.appendChild(td_name);
	
			var td_continent = document.createElement("td");
			td_continent.appendChild(document.createTextNode(count.Continent));
			tr.appendChild(td_continent);

			var td_area = document.createElement("td");
			td_area.appendChild(document.createTextNode(count.AreaInKm2));
			tr.appendChild(td_area);
	
			var td_limit = document.createElement("td");
			td_limit.appendChild(document.createTextNode(count.Population));
			tr.appendChild(td_limit);
	
			var td_capital = document.createElement("td");
			td_capital.appendChild(document.createTextNode(count.Capital));
			tr.appendChild(td_capital);
    
      
			tbody.appendChild(tr);
			table_dev.appendChild(tbody);
		}
		
  }
  )
  ;
	    
}

